"""
THÀNH VIÊN 2: FEATURE SELECTION & REPORTING (Bài 2 - 3 điểm)
Dataset: Student Performance (UCI) - student-mat.csv

Nội dung:
(a) Correlation-based Feature Selection + vẽ Correlation Heatmap
(b) Thử nghiệm các tập features khác nhau với Linear Regression
    -> Dự đoán điểm số cuối kỳ (G3) - bài toán hồi quy
    -> So sánh các tập feature qua MAE (Mean Absolute Error)
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

# ============================================================
# 1. ĐỌC DỮ LIỆU (giống pipeline của Thành viên 1)
# ============================================================
df = pd.read_csv("DATA/student-mat.csv", sep=";")
print("Đọc dữ liệu thành công. Số dòng, số cột:", df.shape)

df = df.dropna()

# Bài 2 dùng Linear Regression -> bài toán hồi quy, mục tiêu là điểm G3 (0-20)
# Không dùng G1, G2 làm input vì đây là điểm giữa kỳ, dùng nó để dự đoán G3 sẽ
# gây "rò rỉ dữ liệu" (data leakage) - điểm G1/G2 gần như quyết định G3.
target = "G3"
X_raw = df.drop(columns=["G1", "G2", "G3"])
y = df[target]

# ============================================================
# 2. MÃ HÓA DỮ LIỆU DẠNG CHỮ (Label Encoding) - giống Thành viên 1
# ============================================================
X_encoded = X_raw.copy()
for col in X_encoded.select_dtypes(include=["object"]).columns:
    le = LabelEncoder()
    X_encoded[col] = le.fit_transform(X_encoded[col])

print("Tiền xử lý dữ liệu thành công.")

# ============================================================
# 3. (a) CORRELATION - Tính ma trận tương quan
# ============================================================
corr_data = X_encoded.copy()
corr_data[target] = y
corr_matrix = corr_data.corr()

# Vẽ Correlation Heatmap toàn bộ
plt.figure(figsize=(16, 13))
sns.heatmap(corr_matrix, cmap="coolwarm", center=0, annot=False,
            linewidths=0.4, cbar_kws={"label": "Hệ số tương quan"})
plt.title("Ma trận tương quan (Correlation Matrix) - Student Performance Dataset",
           fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig("correlation_heatmap_full.png", dpi=150)
plt.close()
print("Đã lưu correlation_heatmap_full.png")

# Tương quan của từng feature với biến mục tiêu G3, sắp xếp theo độ lớn
corr_with_target = corr_matrix[target].drop(target).sort_values(key=abs, ascending=False)

print("\nMức độ tương quan (|corr|) của từng feature với G3 (giảm dần):")
print(corr_with_target.to_string())

# Vẽ bar chart tương quan với target (dễ nhìn hơn cho slide)
plt.figure(figsize=(9, 10))
colors = ["#d62728" if v < 0 else "#1f77b4" for v in corr_with_target.values]
plt.barh(corr_with_target.index[::-1], corr_with_target.values[::-1], color=colors[::-1])
plt.axvline(0, color="black", linewidth=0.8)
plt.xlabel("Hệ số tương quan với G3")
plt.title("Tương quan giữa từng đặc trưng và điểm G3", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("correlation_with_target.png", dpi=150)
plt.close()
print("Đã lưu correlation_with_target.png")

# ============================================================
# 4. (b) CHỌN CÁC TẬP FEATURES KHÁC NHAU DỰA TRÊN CORRELATION
# ============================================================
abs_corr = corr_with_target.abs()

feature_sets = {
    "Toàn bộ features (Full)": list(X_encoded.columns),
    "Tương quan cao (|corr| >= 0.10)": abs_corr[abs_corr >= 0.10].index.tolist(),
    "Top 5 features tương quan mạnh nhất": abs_corr.sort_values(ascending=False).head(5).index.tolist(),
    "Tương quan thấp (|corr| < 0.05) - loại các feature mạnh": abs_corr[abs_corr < 0.05].index.tolist(),
}

print("\nCác tập features được chọn:")
for name, cols in feature_sets.items():
    print(f" - {name} ({len(cols)} features): {cols}")

# ============================================================
# 5. LINEAR REGRESSION TRÊN TỪNG TẬP FEATURES + SO SÁNH MAE
# ============================================================
results = []

for set_name, cols in feature_sets.items():
    if len(cols) == 0:
        continue

    X_sub = X_encoded[cols]
    X_train, X_test, y_train, y_test = train_test_split(
        X_sub, y, test_size=0.2, random_state=42
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = LinearRegression()
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)

    mae = mean_absolute_error(y_test, y_pred)
    results.append({"Feature set": set_name, "Số features": len(cols), "MAE": mae})

results_df = pd.DataFrame(results).sort_values("MAE").reset_index(drop=True)

print("\n===== SO SÁNH HIỆU NĂNG CÁC TẬP FEATURES (Linear Regression, đo bằng MAE) =====")
print(results_df.to_string(index=False))

best_row = results_df.iloc[0]
print(f"\n>>> Tập features tốt nhất: '{best_row['Feature set']}' "
      f"với MAE = {best_row['MAE']:.4f} (dùng {best_row['Số features']} features)")

# Vẽ biểu đồ so sánh MAE giữa các tập feature (dùng cho slide)
plt.figure(figsize=(9, 5))
bars = plt.bar(results_df["Feature set"], results_df["MAE"], color="#2ca02c")
plt.ylabel("MAE (thấp hơn = tốt hơn)")
plt.title("So sánh MAE giữa các tập features (Linear Regression)", fontsize=13, fontweight="bold")
plt.xticks(rotation=20, ha="right")
for b, v in zip(bars, results_df["MAE"]):
    plt.text(b.get_x() + b.get_width() / 2, v, f"{v:.3f}", ha="center", va="bottom")
plt.tight_layout()
plt.savefig("mae_comparison.png", dpi=150)
plt.close()
print("Đã lưu mae_comparison.png")

results_df.to_csv("bai2_mae_results.csv", index=False)
print("\nĐã lưu bảng kết quả: bai2_mae_results.csv")
